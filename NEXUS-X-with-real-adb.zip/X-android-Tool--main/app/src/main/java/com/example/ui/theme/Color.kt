package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nexus Cybernetic Palette
val NexusBackground = Color(0xFF050B16)
val NexusSurface = Color(0xFF081626)
val NexusSurfaceVariant = Color(0xFF0B2033)
val NexusCardBorder = Color(0xFF164A66)

val NexusCyan = Color(0xFF00DFFF)
val NexusCyanDim = Color(0xFF00838F)
val NexusCyanGlow = Color(0x3300E5FF)

val NexusViolet = Color(0xFF8C72FF)
val NexusVioletDim = Color(0xFF651FFF)

val NexusGreen = Color(0xFF00E676)
val NexusGreenDim = Color(0xFF00B0FF)

val NexusAmber = Color(0xFFFFD740)
val NexusRed = Color(0xFFFF5252)

val NexusTextPrimary = Color(0xFFF1F5F9)
val NexusTextSecondary = Color(0xFF94A3B8)
val NexusTextTertiary = Color(0xFF64748B)

val NexusTerminalBg = Color(0xFF05070A)
val NexusTerminalText = Color(0xFF38BDF8)
