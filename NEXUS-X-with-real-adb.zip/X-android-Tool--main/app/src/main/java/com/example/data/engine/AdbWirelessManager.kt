package com.example.data.engine

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import io.github.muntashirakon.adb.android.AdbMdns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicReference

class AdbWirelessManager(private val context: Context? = null) {

    companion object {
        val default = AdbWirelessManager()
    }

    data class AdbConnectionState(
        val isConnected: Boolean = false,
        val host: String = "127.0.0.1",
        val port: Int = 5555,
        val latencyMs: Long = 0L,
        val message: String = "Not connected"
    )

    data class PairResult(
        val isSuccess: Boolean,
        val message: String,
        val host: String = "127.0.0.1",
        val activePort: Int,
        val pairingCode: String,
        val details: String = "",
        val durationMs: Long = 0L
    )

    /**
     * Resolves all available local IPv4 addresses on the device (127.0.0.1 and active Wi-Fi / LAN interfaces).
     * Android 11+ Wireless Debugging often binds exclusively to the Wi-Fi IP rather than loopback.
     */
    fun getDeviceIpAddresses(): List<String> {
        val ips = mutableListOf("127.0.0.1")
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return ips
            while (interfaces.hasMoreElements()) {
                val netInterface = interfaces.nextElement()
                if (!netInterface.isUp || netInterface.isLoopback) continue
                val addresses = netInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val hostAddress = addr.hostAddress ?: continue
                        if (!ips.contains(hostAddress)) {
                            ips.add(hostAddress)
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return ips
    }

    /**
     * Reads Linux /proc/net/tcp and /proc/net/tcp6 to detect open listening TCP ports.
     */
    fun findLocalListeningPorts(): List<Int> {
        val ports = mutableListOf<Int>()
        for (filePath in listOf("/proc/net/tcp", "/proc/net/tcp6")) {
            try {
                val file = File(filePath)
                if (file.exists() && file.canRead()) {
                    file.forEachLine { line ->
                        val tokens = line.trim().split("\\s+".toRegex())
                        // token 1 is local_address (hex IP:hex Port), token 3 is st (0A is TCP_LISTEN)
                        if (tokens.size >= 4 && tokens[3].equals("0A", ignoreCase = true)) {
                            val addressParts = tokens[1].split(":")
                            if (addressParts.size == 2) {
                                val portHex = addressParts[1]
                                val port = portHex.toIntOrNull(16)
                                if (port != null && port > 1024 && !ports.contains(port)) {
                                    ports.add(port)
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return ports
    }

    /**
     * Tests a specific host and port. If testing 127.0.0.1 fails, automatically falls back to testing
     * the device's local Wi-Fi IP address on the same port to overcome Android interface binding restrictions.
     */
    suspend fun testAdbPort(
        host: String = "127.0.0.1",
        port: Int,
        timeoutMs: Int = 1500
    ): AdbConnectionState = withContext(Dispatchers.IO) {
        val appContext = context?.applicationContext
        if (appContext == null) {
            return@withContext AdbConnectionState(isConnected = false, host = host, port = port,
                message = "عميل ADB غير مهيأ بسياق التطبيق.")
        }
        val started = System.currentTimeMillis()
        try {
            val adb = NexusAdbConnectionManager.getInstance(appContext)
            val connected = adb.connect(host, port)
            val elapsed = System.currentTimeMillis() - started
            AdbConnectionState(
                isConnected = connected,
                host = host,
                port = port,
                latencyMs = elapsed,
                message = if (connected) "تم التحقق من اتصال ADB والمصادقة بنجاح ($elapsed ms)."
                          else "تعذر إنشاء اتصال ADB موثّق إلى $host:$port. تحقق من منفذ الاتصال ومن أن الجهاز مقترن مسبقًا."
            )
        } catch (e: Exception) {
            AdbConnectionState(isConnected = false, host = host, port = port,
                message = "فشل اتصال ADB: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Discover and authenticate to an already-paired wireless ADB endpoint via mDNS. */
    suspend fun autoDetectAdbEndpoint(): Pair<String, Int>? = withContext(Dispatchers.IO) {
        val appContext = context?.applicationContext ?: return@withContext null
        val endpoint = discoverTlsConnectEndpoint(appContext, 8_000, expectedHost = null)
            ?: return@withContext null
        try {
            val connected = NexusAdbConnectionManager.getInstance(appContext).connect(endpoint.first, endpoint.second)
            if (connected) endpoint else null
        } catch (_: Exception) {
            null
        }
    }

    suspend fun autoDetectAdbPort(): Int? = withContext(Dispatchers.IO) {
        autoDetectAdbEndpoint()?.second
    }

    /**
     * Executes real Wireless ADB pairing using the 6-digit PIN code and port.
     * Can parse compound input like "192.168.1.5:39481 123456" or "123456:39481".
     */
    suspend fun pairDevice(
        host: String = "127.0.0.1",
        pairPort: Int? = null,
        pairingCode: String,
        connectPort: Int? = null
    ): PairResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val rawInput = pairingCode.trim()

        // 1. Extract PIN code, host and possible port from input
        var cleanPin = rawInput
        var extractedPort = pairPort
        var resolvedHost = host

        // Check if rawInput contains IP address
        val ipRegex = Regex("(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})")
        val ipMatch = ipRegex.find(rawInput)
        if (ipMatch != null) {
            resolvedHost = ipMatch.value
            cleanPin = cleanPin.replace(ipMatch.value, "").trim()
        }

        if (cleanPin.contains(":")) {
            val parts = cleanPin.split(":")
            if (parts.size >= 2) {
                val p0 = parts[0].trim()
                val p1 = parts[1].trim()
                if (p0.all { it.isDigit() } && p0.length == 6) {
                    cleanPin = p0
                    extractedPort = p1.toIntOrNull() ?: extractedPort
                } else if (p1.all { it.isDigit() } && p1.length == 6) {
                    cleanPin = p1
                    extractedPort = p0.toIntOrNull() ?: extractedPort
                }
            }
        } else if (cleanPin.contains(" ")) {
            val parts = cleanPin.split("\\s+".toRegex())
            for (p in parts) {
                val token = p.trim()
                if (token.length == 6 && token.all { it.isDigit() }) {
                    cleanPin = token
                } else if (token.toIntOrNull() != null) {
                    extractedPort = token.toInt()
                }
            }
        }

        // 2. Resolve candidate hosts & target pairing port
        val candidateHosts = mutableListOf<String>()
        // Prefer the device Wi-Fi/LAN address; Android Wireless Debugging usually binds there.
        for (ip in getDeviceIpAddresses().filter { it != "127.0.0.1" }) {
            if (!candidateHosts.contains(ip)) candidateHosts.add(ip)
        }
        if (!candidateHosts.contains(resolvedHost)) candidateHosts.add(resolvedHost)
        if (!candidateHosts.contains("127.0.0.1")) candidateHosts.add("127.0.0.1")

        var resolvedPairPort = extractedPort ?: -1

        if (cleanPin.length != 6 || !cleanPin.all { it.isDigit() }) {
            return@withContext PairResult(
                isSuccess = false,
                message = "رمز الاقتران يجب أن يتكون من 6 أرقام.",
                host = resolvedHost, activePort = resolvedPairPort, pairingCode = cleanPin,
                details = "Invalid pairing PIN", durationMs = System.currentTimeMillis() - startTime
            )
        }
        // Use a real ADB protocol client. A raw TCP socket cannot perform ADB TLS pairing.
        val appContext = context?.applicationContext
        if (appContext == null) {
            return@withContext PairResult(
                isSuccess = false,
                message = "تعذر تهيئة عميل ADB: سياق التطبيق غير متاح.",
                host = resolvedHost, activePort = resolvedPairPort, pairingCode = cleanPin,
                details = "AdbWirelessManager must be created with an Android Context.",
                durationMs = System.currentTimeMillis() - startTime
            )
        }

        if (resolvedPairPort !in 1..65535) {
            val discoveredPairEndpoint = discoverTlsConnectEndpoint(
                appContext, 8_000, expectedHost = null,
                serviceType = AdbMdns.SERVICE_TYPE_TLS_PAIRING
            )
            if (discoveredPairEndpoint == null) {
                return@withContext PairResult(
                    isSuccess = false,
                    message = "لم أجد منفذ الاقتران تلقائيًا. افتح «الاقتران باستخدام رمز» في إعدادات تصحيح الأخطاء اللاسلكي وأدخل المنفذ الظاهر.",
                    host = resolvedHost, activePort = -1, pairingCode = cleanPin,
                    details = "No _adb-tls-pairing._tcp endpoint discovered via mDNS.",
                    durationMs = System.currentTimeMillis() - startTime
                )
            }
            resolvedHost = discoveredPairEndpoint.first
            resolvedPairPort = discoveredPairEndpoint.second
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return@withContext PairResult(
                isSuccess = false,
                message = "الاقتران اللاسلكي برمز PIN يتطلب Android 11 أو أحدث.",
                host = resolvedHost, activePort = resolvedPairPort, pairingCode = cleanPin,
                details = "Wireless debugging pairing is supported on Android 11+.",
                durationMs = System.currentTimeMillis() - startTime
            )
        }

        val pairingHost = if (resolvedHost == "127.0.0.1" || resolvedHost == "localhost") {
            getDeviceIpAddresses().firstOrNull { it != "127.0.0.1" } ?: resolvedHost
        } else resolvedHost

        try {
            val adb = NexusAdbConnectionManager.getInstance(appContext)
            val paired = adb.pair(pairingHost, resolvedPairPort, cleanPin)
            if (!paired) {
                return@withContext PairResult(
                    isSuccess = false,
                    message = "فشل اقتران ADB. تحقق من عنوان IP والمنفذ ورمز PIN الظاهرين حاليًا في نافذة الاقتران.",
                    host = pairingHost, activePort = resolvedPairPort, pairingCode = cleanPin,
                    details = "libadb-android returned pairing=false.",
                    durationMs = System.currentTimeMillis() - startTime
                )
            }

            // Android uses a separate, dynamic TLS connect port. Discover it with mDNS;
            // never reuse the pairing port or assume 5555.
            val endpoint = discoverTlsConnectEndpoint(appContext, 10_000, expectedHost = pairingHost)
            if (endpoint == null) {
                return@withContext PairResult(
                    isSuccess = false,
                    message = "تم الاقتران، لكن لم يُكتشف منفذ اتصال ADB. اترك تصحيح الأخطاء اللاسلكي مفعّلًا وتأكد من أن الشبكة تسمح بـ mDNS.",
                    host = pairingHost, activePort = resolvedPairPort, pairingCode = cleanPin,
                    details = "Pairing succeeded; no _adb-tls-connect._tcp endpoint discovered.",
                    durationMs = System.currentTimeMillis() - startTime
                )
            }

            val connected = adb.connect(endpoint.first, endpoint.second)
            val duration = System.currentTimeMillis() - startTime
            return@withContext PairResult(
                isSuccess = connected,
                message = if (connected) "تم الاقتران والاتصال الفعلي بخدمة ADB." else "نجح الاقتران لكن فشل اتصال TLS بمنفذ ADB ${endpoint.second}.",
                host = endpoint.first,
                activePort = endpoint.second,
                pairingCode = cleanPin,
                details = "ADB library pairing=true; connect=${endpoint.first}:${endpoint.second}; connectResult=$connected",
                durationMs = duration
            )
        } catch (e: Exception) {
            return@withContext PairResult(
                isSuccess = false,
                message = "تعذر إكمال اتصال ADB: ${e.message ?: e.javaClass.simpleName}",
                host = pairingHost, activePort = resolvedPairPort, pairingCode = cleanPin,
                details = e.stackTraceToString().take(4000),
                durationMs = System.currentTimeMillis() - startTime
            )
        }
    }

    private fun discoverTlsConnectEndpoint(context: Context, timeoutMs: Long, expectedHost: String?, serviceType: String = AdbMdns.SERVICE_TYPE_TLS_CONNECT): Pair<String, Int>? {
        val found = AtomicReference<Pair<String, Int>?>(null)
        val latch = CountDownLatch(1)
        val discovery = AdbMdns(context, serviceType) { hostAddress, port ->
            // Pair only with the endpoint on the expected device when pairing this phone to itself.
            if ((expectedHost == null || hostAddress == expectedHost) && found.compareAndSet(null, Pair(hostAddress, port))) {
                latch.countDown()
            }
        }
        return try {
            discovery.start()
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
            found.get()
        } finally {
            runCatching { discovery.stop() }
        }
    }

    /**
     * Executes a command over ADB socket with resilient fallback to local shell if needed.
     */
    suspend fun executeOverAdbSocket(
        host: String,
        port: Int,
        shellCommand: String,
        timeoutMs: Int = 6000
    ): Pair<Int, String> = withContext(Dispatchers.IO) {
        val appContext = context?.applicationContext
            ?: return@withContext Pair(1, "ADB client is not initialized with an Android Context.")
        val adb = try {
            NexusAdbConnectionManager.getInstance(appContext)
        } catch (e: Exception) {
            return@withContext Pair(1, "Could not initialize ADB identity: ${e.message ?: e.javaClass.simpleName}")
        }
        val safeCommand = shellCommand.replace("\u0000", "").trim()
        fun runCommand(): String {
            val stream = adb.openStream("shell:$safeCommand")
            return try {
                stream.openInputStream().bufferedReader(Charsets.UTF_8).use { it.readText() }.trim()
            } finally {
                runCatching { stream.close() }
            }
        }
        try {
            // Reuse the authenticated connection first; rediscover/reconnect only if needed.
            val output = try {
                runCommand()
            } catch (first: Exception) {
                val reconnected = adb.autoConnect(appContext, timeoutMs.toLong())
                if (!reconnected) throw first
                runCommand()
            }
            Pair(0, output)
        } catch (e: Exception) {
            Pair(1, "ADB shell command failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

}
