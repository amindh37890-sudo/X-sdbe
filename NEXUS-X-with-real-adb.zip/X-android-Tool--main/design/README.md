# NEXUS X UI Reference

`NEXUS_X_UI_REFERENCE.png` is a visual reference for the dark navy, cyan holographic, rounded-card interface. It is a concept mockup, not a screenshot of the running application; verify every feature in the Android project before describing it as functional.
