# Third-party notices

NEXUS X integrates `com.github.MuntashirAkon:libadb-android:3.1.1` for ADB protocol, TLS pairing/authentication, and shell streams. The upstream project states that it is dual-licensed under GPL-3.0-or-later or Apache-2.0 and notes an LGPL dependency. Review the upstream license files and dependency licenses before redistributing this application.

The project also depends on `com.github.MuntashirAkon:sun-security-android:1.1` and `org.conscrypt:conscrypt-android:2.5.3`. Their respective license texts must be included or made available as required by their licenses.

Upstream project: https://github.com/MuntashirAkon/libadb-android
