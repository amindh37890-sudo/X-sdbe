package com.example.data.engine

import android.content.Context
import android.os.Build
import android.sun.security.x509.AlgorithmId
import android.sun.security.x509.CertificateAlgorithmId
import android.sun.security.x509.CertificateExtensions
import android.sun.security.x509.CertificateIssuerName
import android.sun.security.x509.CertificateSerialNumber
import android.sun.security.x509.CertificateSubjectName
import android.sun.security.x509.CertificateValidity
import android.sun.security.x509.CertificateVersion
import android.sun.security.x509.CertificateX509Key
import android.sun.security.x509.KeyIdentifier
import android.sun.security.x509.PrivateKeyUsageExtension
import android.sun.security.x509.SubjectKeyIdentifierExtension
import android.sun.security.x509.X500Name
import android.sun.security.x509.X509CertImpl
import android.sun.security.x509.X509CertInfo
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.atomic.AtomicReference

/** Persistent ADB identity used by libadb-android for real ADB pairing and TLS authentication. */
class NexusAdbConnectionManager private constructor(context: Context) : AbsAdbConnectionManager() {
    private val appContext = context.applicationContext
    private val privateKey: PrivateKey
    private val certificate: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val keyFile = File(appContext.filesDir, "adb/adbkey.pk8")
        val certFile = File(appContext.filesDir, "adb/adbcert.der")
        keyFile.parentFile?.mkdirs()
        val loaded = runCatching {
            val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyFile.readBytes()))
            val cert = CertificateFactory.getInstance("X.509").generateCertificate(certFile.inputStream().use { it })
            key to cert
        }.getOrNull()

        if (loaded != null) {
            privateKey = loaded.first
            certificate = loaded.second
        } else {
            val generator = KeyPairGenerator.getInstance("RSA")
            generator.initialize(2048, SecureRandom())
            val keyPair = generator.generateKeyPair()
            privateKey = keyPair.private
            certificate = createCertificate(keyPair.public, privateKey)
            keyFile.writeBytes(privateKey.encoded)
            certFile.writeBytes(certificate.encoded)
        }
    }

    private fun createCertificate(publicKey: java.security.PublicKey, signingKey: PrivateKey): Certificate {
        val now = Date()
        val expiry = Date(System.currentTimeMillis() + 10L * 365 * 24 * 60 * 60 * 1000)
        val algorithm = "SHA256withRSA"
        val name = X500Name("CN=NEXUS X ADB")
        val extensions = CertificateExtensions()
        extensions.set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(publicKey).identifier))
        extensions.set("PrivateKeyUsage", PrivateKeyUsageExtension(now, expiry))

        val info = X509CertInfo()
        info.set("version", CertificateVersion(2))
        info.set("serialNumber", CertificateSerialNumber(BigInteger.valueOf((System.nanoTime() and Long.MAX_VALUE).coerceAtLeast(1L))))
        info.set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(algorithm)))
        info.set("subject", CertificateSubjectName(name))
        info.set("key", CertificateX509Key(publicKey))
        info.set("validity", CertificateValidity(now, expiry))
        info.set("issuer", CertificateIssuerName(name))
        info.set("extensions", extensions)
        return X509CertImpl(info).apply { sign(signingKey, algorithm) }
    }

    override fun getPrivateKey(): PrivateKey = privateKey
    override fun getCertificate(): Certificate = certificate
    override fun getDeviceName(): String = "NEXUS-X"

    companion object {
        @Volatile private var instance: NexusAdbConnectionManager? = null
        fun getInstance(context: Context): NexusAdbConnectionManager = instance ?: synchronized(this) {
            instance ?: NexusAdbConnectionManager(context).also { instance = it }
        }
    }
}
